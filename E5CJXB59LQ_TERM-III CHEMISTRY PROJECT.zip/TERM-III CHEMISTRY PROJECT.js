function predict() {
    let bonds = parseInt(document.getElementById("bonds").value);
    let lone = parseInt(document.getElementById("lonepairs").value);

    if (isNaN(bonds) || isNaN(lone)) {
        document.getElementById("result").innerHTML = "⚠ Please enter both values";
        return;
    }

    let steric = bonds + lone;
    let hybrid = "";
    let output = "";

    // 🔹 Hybridization mapping
    if (steric === 2) hybrid = "sp";
    else if (steric === 3) hybrid = "sp²";
    else if (steric === 4) hybrid = "sp³";
    else if (steric === 5) hybrid = "sp³d";
    else if (steric === 6) hybrid = "sp³d²";

    // -------- STERIC 2 --------
    if (steric === 2) {
        output = `<h2>Linear (180°)</h2>
        <h3>Hybridization: ${hybrid}</h3>
        <p>Example: CO₂</p>
        <svg viewBox="0 0 300 300">
            <line x1="50" y1="150" x2="250" y2="150"/>
            <text x="30" y="155">O</text>
            <text x="145" y="155">C</text>
            <text x="260" y="155">O</text>
        </svg>`;
    }

    // -------- STERIC 3 --------
    else if (steric === 3) {
        if (lone === 0) {
            output = `<h2>Trigonal Planar (120°)</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: BF₃</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="80" x2="50" y2="220"/>
                <line x1="150" y1="80" x2="250" y2="220"/>
                <line x1="50" y1="220" x2="250" y2="220"/>
                <text x="140" y="70">B</text>
                <text x="40" y="240">F</text>
                <text x="250" y="240">F</text>
                <text x="140" y="260">F</text>
            </svg>`;
        } else if (lone === 1) {
            output = `<h2>Bent (V-Shape)</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: SO₂</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="150" x2="80" y2="220"/>
                <line x1="150" y1="150" x2="220" y2="220"/>
                <text x="145" y="155">S</text>
                <text x="60" y="240">O</text>
                <text x="220" y="240">O</text>
                <text x="140" y="80">LP</text>
            </svg>`;
        }
    }

    // -------- STERIC 4 --------
    else if (steric === 4) {
        if (lone === 0) {
            output = `<h2>Tetrahedral (109.5°)</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: CH₄</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="150" x2="150" y2="50"/>
                <line x1="150" y1="150" x2="60" y2="240"/>
                <line x1="150" y1="150" x2="240" y2="240"/>
                <line class="dashed" x1="150" y1="150" x2="150" y2="240"/>
                <text x="145" y="155">C</text>
                <text x="140" y="40">H</text>
                <text x="40" y="260">H</text>
                <text x="250" y="260">H</text>
                <text x="140" y="280">H</text>
            </svg>`;
        } else if (lone === 1) {
            output = `<h2>Trigonal Pyramidal</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: NH₃</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="150" x2="60" y2="240"/>
                <line x1="150" y1="150" x2="240" y2="240"/>
                <line x1="150" y1="150" x2="150" y2="70"/>
                <text x="145" y="155">N</text>
                <text x="40" y="260">H</text>
                <text x="250" y="260">H</text>
                <text x="140" y="60">H</text>
                <text x="140" y="260">LP</text>
            </svg>`;
        } else if (lone === 2) {
            output = `<h2>Bent (V-Shape)</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: H₂O</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="150" x2="80" y2="220"/>
                <line x1="150" y1="150" x2="220" y2="220"/>
                <text x="145" y="155">O</text>
                <text x="60" y="240">H</text>
                <text x="220" y="240">H</text>
                <text x="120" y="80">LP</text>
                <text x="180" y="80">LP</text>
            </svg>`;
        }
    }

    // -------- STERIC 5 --------
    else if (steric === 5) {

        if (lone === 0) {
            output = `<h2>Trigonal Bipyramidal</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: PCl₅</p>
            <svg viewBox="0 0 300 300">
                <!-- axial -->
                <line x1="150" y1="40" x2="150" y2="260"/>
                <!-- equatorial -->
                <line x1="150" y1="150" x2="60" y2="200"/>
                <line x1="150" y1="150" x2="240" y2="200"/>
                <line x1="60" y1="200" x2="240" y2="200"/>
                <text x="145" y="155">P</text>
                <text x="140" y="30">Cl</text>
                <text x="140" y="280">Cl</text>
                <text x="40" y="210">Cl</text>
                <text x="250" y="210">Cl</text>
                <text x="140" y="230">Cl</text>
            </svg>`;
        } else if (lone === 1) {
            output = `<h2>Seesaw Shape</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: SF₄</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="40" x2="150" y2="260"/>
                <line x1="150" y1="150" x2="60" y2="220"/>
                <line x1="150" y1="150" x2="240" y2="220"/>
                <text x="145" y="155">S</text>
                <text x="140" y="30">F</text>
                <text x="140" y="280">F</text>
                <text x="40" y="240">F</text>
                <text x="250" y="240">F</text>
                <text x="140" y="90">LP</text>
            </svg>`;
        } else if (lone === 2) {
            output = `<h2>T-Shaped</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: ClF₃</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="40" x2="150" y2="260"/>
                <line x1="150" y1="150" x2="60" y2="150"/>
                <text x="145" y="155">Cl</text>
                <text x="140" y="30">F</text>
                <text x="140" y="280">F</text>
                <text x="40" y="155">F</text>
                <text x="200" y="100">LP</text>
                <text x="200" y="200">LP</text>
            </svg>`;
        } else if (lone === 3) {
            output = `<h2>Linear</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: XeF₂</p>
            <svg viewBox="0 0 300 300">
                <line x1="50" y1="150" x2="250" y2="150"/>
                <text x="30" y="155">F</text>
                <text x="145" y="155">Xe</text>
                <text x="260" y="155">F</text>
                <text x="120" y="80">LP</text>
                <text x="150" y="60">LP</text>
                <text x="180" y="80">LP</text>
            </svg>`;
        }
    }

    // -------- STERIC 6 --------
    else if (steric === 6) {

        if (lone === 0) {
            output = `<h2>Octahedral</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: SF₆</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="40" x2="150" y2="260"/>
                <line x1="40" y1="150" x2="260" y2="150"/>
                <line class="dashed" x1="80" y1="80" x2="220" y2="220"/>
                <line class="dashed" x1="220" y1="80" x2="80" y2="220"/>
                <text x="145" y="155">S</text>
                <text x="140" y="30">F</text>
                <text x="140" y="280">F</text>
                <text x="20" y="155">F</text>
                <text x="270" y="155">F</text>
                <text x="70" y="70">F</text>
                <text x="220" y="70">F</text>
            </svg>`;
        } else if (lone === 1) {
            output = `<h2>Square Pyramidal</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: BrF₅</p>
            <svg viewBox="0 0 300 300">
                <line x1="150" y1="60" x2="150" y2="150"/>
                <rect x="80" y="150" width="140" height="80" fill="none" stroke="white"/>
                <text x="145" y="155">Br</text>
                <text x="140" y="50">F</text>
                <text x="80" y="250">F</text>
                <text x="200" y="250">F</text>
                <text x="80" y="150">F</text>
                <text x="200" y="150">F</text>
                <text x="140" y="260">LP</text>
            </svg>`;
        } else if (lone === 2) {
            output = `<h2>Square Planar</h2>
            <h3>Hybridization: ${hybrid}</h3>
            <p>Example: XeF₄</p>
            <svg viewBox="0 0 300 300">
                <rect x="80" y="100" width="140" height="100" fill="none" stroke="white"/>
                <text x="145" y="155">Xe</text>
                <text x="80" y="100">F</text>
                <text x="220" y="100">F</text>
                <text x="80" y="200">F</text>
                <text x="220" y="200">F</text>
                <text x="140" y="60">LP</text>
                <text x="140" y="260">LP</text>
            </svg>`;
        }
    }

    document.getElementById("result").innerHTML = output;
}